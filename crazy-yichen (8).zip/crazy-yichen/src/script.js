// Scroll to top functionality
const scrollTopBtn = document.createElement('button');
scrollTopBtn.innerHTML = '↑';
scrollTopBtn.id = 'scrollToTopBtn';
document.body.appendChild(scrollTopBtn);

// Show scroll to top button when scrolled down
window.onscroll = () => {
    if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
        scrollTopBtn.style.display = 'block';
    } else {
        scrollTopBtn.style.display = 'none';
    }
};

// Smooth scroll to the top
scrollTopBtn.onclick = () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
};

// Smooth scrolling for anchor links
const links = document.querySelectorAll('a[href^="#"]');
links.forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();

        const targetElement = document.querySelector(this.getAttribute('href'));
        targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    });
});

// Hamburger menu functionality for mobile devices
const hamburgerMenu = document.querySelector('.hamburger-menu');
const navLinks = document.querySelector('header nav ul');

if (hamburgerMenu) {
    hamburgerMenu.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });
}

// Hover effect on books section (show description)
const books = document.querySelectorAll('.book');

books.forEach(book => {
    const description = book.querySelector('.book-description');
    if (description) {
        book.addEventListener('mouseenter', () => {
            description.style.display = 'block';  // Show description
        });
        book.addEventListener('mouseleave', () => {
            description.style.display = 'none';  // Hide description
        });
    }
});